import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;



public class ArrayListImproved<T extends Comparable <? super T>> extends ArrayList<T> {
	
	
	public void sort(int start, int end) {
		int t = end;
		T tmp;
		for(int j = 0;j*2 < (end-start);j++){	   
			for(int i = start;i < end; i++){
				if(this.get(i).compareTo(this.get(i+1)) > 0){
					tmp= this.get(i);
					this.set(i, this.get(i+1));
					this.set(i+1, tmp);
				}
				if(this.get(t).compareTo(this.get(t-1)) < 0){
					tmp= this.get(t);
					this.set(t, this.get(t-1));
					this.set(t-1, tmp);
				}
				t--;
			}
			t = end;
		}
	}
	
	public void sort(int start, int end, Comparator c){
		int t = end;
		T tmp;
		
		for(int j = 0;j*2 < (end-start);j++){	   
			for(int i = start;i < end; i++){
				if(c.compare(this.get(i),this.get(i+1)) > 0){
					tmp= this.get(i);
					this.set(i, this.get(i+1));
					this.set(i+1, tmp);
				}
				if(c.compare(this.get(t),this.get(t-1)) < 0){
					tmp= this.get(t);
					this.set(t, this.get(t-1));
					this.set(t-1, tmp);
				}
				t--;
			}
			t = end;
		}
	}
	
	public void randomize(int start, int end){
		
		int random;
		T tmp;
		for( int i = start; i <= end; i++){
			random = (int) (Math.random()*end);
			if( random < start )
			{
				random = random + start;
			}
			tmp = this.get(i);
			this.set(i,this.get(random));
			this.set(random,tmp);					
		}
	}
}
