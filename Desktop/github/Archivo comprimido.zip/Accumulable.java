


public interface Accumulable<T>{
	
	T accummulate(T t1,T t2);

}
