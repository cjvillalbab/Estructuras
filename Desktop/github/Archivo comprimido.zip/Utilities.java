
public class Utilities <T extends Comparable <? super T>> {
	
	public T fold(ArrayListImproved<T> list){
		T acc = list.get(0);
		for(int i = 1; i < list.size(); i++)
		{
			acc = accummulate(acc,list.get(i));
		}
		return acc;
	}
}


