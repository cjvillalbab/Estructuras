import java.util.ArrayList;


public class Search {
	
	static ArrayList<Integer> indexList = new ArrayList<Integer>();
	 
	public static void search(ArrayList<Student> studentList,double average, int position ) {
		
	  for(int i = 0;i < studentList.size();i = 100+i){   
		   if(i+100>=studentList.size()){
			    int h=studentList.size()%100;    
			    boundedSearch(i,i+h+100,average,studentList); 
		   }else
			   boundedSearch(i,i+100,average,studentList);  
			   
	  }	  
	  if(indexList.size() >= position)
		 System.out.println(studentList.get(indexList.get(position)).getLastName()+" "+studentList.get(indexList.get(position)).getId());
	}
	
	public static void boundedSearch(int p1, int p2,double a,ArrayList<Student> studentList){
	  for(int w = p1; w < p2-1; w++)
		  if(studentList.get(w).getAverage()>=a)
			  indexList.add(w);
	}
}
