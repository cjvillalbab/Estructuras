
public class Student {
	
	private String lastName;
	private int id;
	private double average;
	
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getAverage() {
		return average;
	}
	public void setAverage(double average) {
		this.average = average;
	}
	
	public Student(String lastName, int id, double average) {
		super();
		this.lastName = lastName;
		this.id = id;
		this.average = average;
	}
}
