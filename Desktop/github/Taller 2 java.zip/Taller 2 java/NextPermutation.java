
public class NextPermutation {
	
	public static <T extends Comparable> T[] nextPermutation(T[] array) {

	    int lessPosition = array.length - 1;
	    while (lessPosition > 0 && array[lessPosition - 1].compareTo(array[lessPosition]) >= 0 )
	    	lessPosition--;

	    if (lessPosition == 0){
	        return array;
	    }

	    int higherPosition = array.length - 1;
	    while (array[higherPosition].compareTo(array[lessPosition - 1]) <= 0 )
	    	higherPosition--;

	    T temp = array[lessPosition - 1];
	    array[lessPosition - 1] = array[higherPosition];
	    array[higherPosition] = temp;
	    
	    higherPosition = array.length - 1; 
	    while (lessPosition < higherPosition) {
	        temp = array[lessPosition];
	        array[lessPosition] = array[higherPosition];
	        array[higherPosition] = temp;
	        lessPosition++;
	        higherPosition--;
	    }
	    return array;
	}
}
